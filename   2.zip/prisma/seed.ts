// Database seed for the Algerian law professor website.
// Run with: bun run prisma/seed.ts
import { db } from "../src/lib/db";
import { fallbackData } from "./seed-data";

async function main() {
  // Wipe existing data to keep the seed idempotent.
  await db.contactMessage.deleteMany();
  await db.newsItem.deleteMany();
  await db.officeHour.deleteMany();
  await db.publication.deleteMany();
  await db.course.deleteMany();
  await db.professor.deleteMany();

  const p = await db.professor.create({
    data: {
      fullName: fallbackData.professor.fullName,
      title: fallbackData.professor.title,
      rank: fallbackData.professor.rank,
      university: fallbackData.professor.university,
      faculty: fallbackData.professor.faculty,
      department: fallbackData.professor.department,
      email: fallbackData.professor.email,
      phone: fallbackData.professor.phone,
      office: fallbackData.professor.office,
      avatarUrl: fallbackData.professor.avatarUrl,
      shortBio: fallbackData.professor.shortBio,
      longBio: fallbackData.professor.longBio,
      education: fallbackData.professor.education,
      researchInterests: fallbackData.professor.researchInterests,
      yearsExperience: fallbackData.professor.yearsExperience,
      publicationsCount: fallbackData.professor.publicationsCount,
      supervisedTheses: fallbackData.professor.supervisedTheses,
      coursesCount: fallbackData.professor.coursesCount,
    },
  });

  await db.course.createMany({
    data: fallbackData.courses.map((c) => ({ ...c, professorId: p.id })),
  });
  await db.publication.createMany({
    data: fallbackData.publications.map((p2) => ({
      ...p2,
      professorId: p.id,
    })),
  });
  await db.officeHour.createMany({
    data: fallbackData.officeHours.map((o) => ({ ...o, professorId: p.id })),
  });
  await db.newsItem.createMany({
    data: fallbackData.news.map((n) => ({
      ...n,
      professorId: p.id,
      date: new Date(n.date),
    })),
  });

  console.log("✓ Seed complete:", {
    professor: 1,
    courses: fallbackData.courses.length,
    publications: fallbackData.publications.length,
    officeHours: fallbackData.officeHours.length,
    news: fallbackData.news.length,
  });
}

main()
  .catch((err) => {
    console.error("Seed failed:", err);
    process.exit(1);
  })
  .finally(async () => {
    await db.$disconnect();
  });
