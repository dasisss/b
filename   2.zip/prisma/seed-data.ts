// Seed payload mirroring the fallback UI data, with id fields stripped so the
// DB can generate its own ids.
import { fallbackProfessor, fallbackCourses, fallbackPublications, fallbackOfficeHours, fallbackNews } from "../src/lib/fallback-data";

function strip<T extends { id: string }>(arr: T[]): Omit<T, "id">[] {
  return arr.map(({ id: _id, ...rest }) => rest as Omit<T, "id">);
}

export const fallbackData = {
  professor: fallbackProfessor,
  courses: strip(fallbackCourses),
  publications: strip(fallbackPublications),
  officeHours: strip(fallbackOfficeHours),
  news: strip(fallbackNews).map((n) => ({ ...n, date: n.date })),
};
